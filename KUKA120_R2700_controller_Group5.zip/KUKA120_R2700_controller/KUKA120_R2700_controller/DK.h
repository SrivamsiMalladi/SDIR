#include <vector>
#include <array>
using namespace std;

/**
 * This class is intended to handle the direct kinematic computation from a given configuration
 */
class FwKinematics {
public:
    /**
     * Computes the forward kinematic from a given {@Configuration}
     * @param _cfg {@Configuration} to compute the forward kinematic from
     * @return computed {@ref SixDPos}
     */
    double* get_fw_kinematics(double* _cfg);
    double* fwFunction(double t1, double t2, double t3, double t4, double t5, double t6);

};

