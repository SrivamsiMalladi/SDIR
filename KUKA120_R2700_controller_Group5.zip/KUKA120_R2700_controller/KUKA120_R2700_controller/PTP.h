/**
 * This class implementes the lin movement from to given {@ref Configuration}, one for the start configuration and one
 * for the target configuration.
 *
 * TODO: ensure that you always stay within the physical limits of the robot, i.e., accelaration, verlocity, and rotation
 *       values of the physical joints.
 */
class Ptp {
public:
    /**
     * Example function computing the trajectory for a given path (defined by two configurations) as lin movement.
     *
     * @param _start_cfg {@ref Configruation} of the starting point of the path
     * @param _end_cfg {@ref Configruation} of the target point of the path
     * @return {@ref Trajectoy} for the movement of the robot
     */
    double asynchronous(double* theta_start, double* theta_end);
    double synchronous(double* theta_start, double* theta_end);
    double noplateauconfig(double* theta_start, double* theta_end, double* t_mean, double* t_max, double* end_time, int i);
    double plateauconfig(double theta_start[], double theta_end[], double* t_mean, double* t_max, double* end_time, int i);
};