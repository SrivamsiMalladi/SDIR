// KUKA120_R2700_controller.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
#include "IK.h"
#include "DK.h"
#include "LIN.h"
#include "PTP.h"
#include<vector>
#include<array>

#define _USE_MATH_DEFINES
#include <math.h>


int main()
{
    ////Direct Kinematics
    //cout << "---------------Forward Kinematics--------------\n";
    //double cfg1[6] = { 90, - 45,  0,  180, - 90, - 45};
    //double cfg2[6] = { 80, -35,  10,  190, -100, -55 };

    //FwKinematics fwKinematics;
    //double* new_pos1 = fwKinematics.get_fw_kinematics(cfg1);
    //double* new_pos2 = fwKinematics.get_fw_kinematics(cfg2);

    //Inverse Kinematics
    cout << "---------------Inverse Kinematics---------------\n";
    //double pos1[8] = { 314.099985, 31.3148732, 2934.78492, 0.217491, 0.226049, 1.3025, 0, 0 };
    double pos1[8] = { 215, 215, 2934.78492, 0.217491, 0.226049, 1.3025, 143, 0 };
    //double pos2[8] = {414.099985, 131.3148732, 2834.78492, 0.217491, 0.226049, 1.3025, 0, 0};
    InvKinematics invKinematics;
    vector<array<double, 6>>* new_cfg1 = invKinematics.get_inv_kinematics(pos1);
    //vector<array<double, 6>>* new_cfg2 = invKinematics.get_inv_kinematics(pos2);

    ////LIN Movement 
    //cout << "-----------------LIN Movement----------------\n";
    //double startCfg[6] = { 90, -45,  0,  180, -90, -45 };
    //double endCfg[6] = { 70, -15,  110,  190, -100, -55 };
    //Lin lin;
    //lin.get_lin_trajectoy(startCfg, endCfg);

    //double startCfg[3] = { 30, -45,  35};
    //double endCfg[3] = { 180, 135, -10};
    //lin.get_lin_points(startCfg, endCfg);

    //PTP Movement
    //cout << "Enter the start angles for each joint";
    //double t1, t2, t3, t4, t5, t6;
    //cout << "Enter the end angles for each joint";
    //double t7, t8, t9, t10, t11, t12;

    Ptp ptp;

    double theta_start[6] = { 0 * (M_PI / 180),20 * (M_PI / 180),-90 * (M_PI / 180),-45 * (M_PI / 180) ,45 * (M_PI / 180) ,90 * (M_PI / 180) };
    double theta_end[6] = { 23 * (M_PI / 180) ,45 * (M_PI / 180) ,56 * (M_PI / 180),90 * (M_PI / 180),45 * (M_PI / 180) ,-45 * (M_PI / 180) };

    /*double theta_start[6] = { t1 * (M_PI / 180),t2 * (M_PI / 180),t3 * (M_PI / 180),t4 * (M_PI / 180),t5 * (M_PI / 180),t6 * (M_PI / 180) };
    double theta_end[6] = { t7 * (M_PI / 180),t8 * (M_PI / 180),t9 * (M_PI / 180),t10 * (M_PI / 180),t11 * (M_PI / 180),t12 * (M_PI / 180) };*/

    //cout << ptp.asynchronous(theta_start, theta_end);
    //cout << ptp.synchronous(theta_start, theta_end);
}