#include <iostream>
using namespace std;
#include <math.h>
#include <cmath>
#include <vector>
#include <algorithm>
#define _USE_MATH_DEFINES
#define M_PI (3.14159)

#include "PTP.h"


double theta, vel, acc;
double t_max[6] = { 0,0,0,0,0,0 };
double theta_max[6] = { 0,0,0,0,0,0 };
double end_time[6] = { 0,0,0,0,0,0 };
//double new_max_vel[] = {0};
double new_max_acc[] = { 0 };
double theta_result[] = { 0 };
double vel_result[] = { 0 };
double t_max_new[] = { 0 };
double acc_result[] = { 0 };
double max_vel[] = { 2.09439,2.00712,2.09439,3.31612,3.14159,4.5378 }; //Maximum velocities in radians per sec
double max_acc[] = { 20.9439,20.0712,20.9439,33.16125,31.4159,45.378 }; //Maximum accelerations = maximum velocity*10
//double max_acc[] = { 1200*(M_PI / 180),1150 * (M_PI / 180),1200 * (M_PI / 180),1900 * (M_PI / 180),1800 * (M_PI / 180),2600 * (M_PI / 180) };

//Asynchronous PTP//

//vector<double*>* noplateauconfig(double theta_start[], double theta_end[], double* t_mean, double* t_max, double* end_time,int i) {
double Ptp::noplateauconfig(double* theta_start, double* theta_end, double* t_mean, double* t_max, double* end_time, int i) {

	/*vector<double> trajectoryResult;*/
	//cout << "Testing theta_start " << theta_start[0] * 180 / M_PI << " " << theta_start[1] * 180 / M_PI << " " << theta_start[2] * 180 / M_PI << " " << theta_start[3] * 180 / M_PI << "\n";

	for (double t = 0; t < end_time[i]; t += 0.01) {

		/*vector<double>* thisIteration;*/
		if (t <= t_mean[i]) {
			theta = theta_start[i] + 0.5 * max_acc[i] * t * t;

			vel = max_acc[i] * t;

			acc = max_acc[i];
		}
		if (t > t_mean[i]) {
			theta = theta_start[i] + (0.5 * max_acc[i] * t * t) - (0.5 * max_acc[i] * (t - end_time[i]) * (t - end_time[i])) + (0.5 * max_acc[i] * t_mean[i] * t_mean[i]);

			vel = -max_acc[i] * (t - t_mean[i]) + max_acc[i] * t_mean[i];

			acc = -max_acc[i];
		}
		/*thisIteration->push_back(theta);
		thisIteration->push_back(vel);
		thisIteration->push_back(acc);

		trajectoryResult.push_back(thisIteration);*/
		/*theta_result[t] = { theta };
		vel_result[t] = {vel};
		acc_result[t] = {acc};*/

		cout << t << " " << theta << " " << vel << " " << acc << "\n";
	}
	//return theta_result[t], vel_result[t], acc_result[t];
	return theta, vel, acc;

}

double Ptp::plateauconfig(double theta_start[], double theta_end[], double* t_mean, double* t_max, double* end_time, int i) {

	for (double t = 0; t < end_time[i]; t += 0.01) {

		if (t <= t_max[i]) {
			theta = 0.5 * max_acc[i] * t * t;

			vel = max_acc[i] * t;

			acc = max_acc[i];
		}
		else if (t_max[i] < t && t <= (end_time[i] - t_max[i])) {

			theta = (0.5 * max_acc[i] * t * t) + (t - t_max[i]) * vel;
			vel = max_vel[i];
			acc = 0;
		}
		else if ((end_time[i] - t_max[i]) < t) {
			theta = (0.5 * max_acc[i] * end_time[i] * end_time[i]) + ((end_time[i] - 2 * t_max[i]) * max_vel[i]) - (0.5 * max_acc[i] * (t - t_max[i]) * (t - t_max[i])) + (0.5 * max_acc[i] * end_time[i] * end_time[i]);
			vel = max_vel[i] - ((t - ((end_time[i] - t_max[i])) * max_acc[i]));
			acc = -max_acc[i];
		}

		cout << t << " " << theta << " " << vel << " " << acc << "\n";

	}

	return theta, vel, acc;

}
double Ptp::asynchronous(double* theta_start, double* theta_end) {

	for (int i = 0; i < 6; i++) {

		t_max[i] = max_vel[i] / max_acc[i];
		double cond = 0.5 * max_acc[i] * t_max[i] * t_max[i];
		double theta_mean[] = { (theta_end[i] - theta_start[i]) / 2 };
		double t_mean[] = { sqrt((2 * theta_mean[i]) / max_acc[i]) };
		theta_max[i] = 0.5 * max_acc[i] * t_max[i] * t_max[i];
		end_time[i] = 2 * t_max[i] + ((theta_end[i] - theta_start[i] - 2 * theta_max[i]) / max_vel[i]);

		if (cond < theta_mean[i]) {
			plateauconfig(theta_start, theta_end, t_mean, t_max, end_time, i);
		}
		if (cond >= theta_mean[i]) {
			noplateauconfig(theta_start, theta_end, t_mean, t_max, end_time, i);
		}
	}

	return theta, vel, acc;

}

//SynchronousPTP

double Ptp::synchronous(double* theta_start, double* theta_end) {
	double T[6] = {};
	for (int i = 0; i < 6; i++) {
		t_max_new[i] = max_vel[i] / new_max_acc[i];
		theta_max[i] = 0.5 * max_acc[i] * t_max_new[i] * t_max_new[i];
		end_time[i] = 2 * t_max_new[i] + ((theta_end[i] - theta_start[i] - 2 * theta_max[i]) / max_vel[i]);
		T[i] = end_time[i];
	}
	double max_Time = max(T[0], max(T[1], max(T[2], max(T[3], max(T[4], T[5])))));

	////Limit Maximum velocity
	// for ( int i = 0; i < 6; i++) {
	// if (fabs(max_acc[i]) >= (4 * fabs(theta_start[i] * theta_end[i]) / (end_time[i] * end_time[i]))) {
	// t_max[i] = 0.5 * end_time[i] - (0.5 * sqrt(((end_time[i] * end_time[i] * max_acc[i]) - 4 * (theta_end - theta_start)) / max_acc[i]));
	// new_max_vel[i] = ((fabs(theta_end[i] - theta_start[i]) - (t_max[i] * t_max[i] * max_acc[i])) / (end_time[i] - 2 * t_max[i]));
	// }
	// }

	//Limit maximum acceleration//
	for (int i = 0; i < 6; i++) {
		double theta_mean[] = { (theta_end[i] - theta_start[i]) / 2 };
		double t_mean_new[] = { sqrt((2 * theta_mean[i]) / new_max_acc[i]) };
		if (max_Time != T[i]) {

			if ((fabs(theta_end[i] - theta_start[i]) / max_Time) <= fabs(max_vel[i]) <= (2 * fabs(theta_end[i] - theta_start[i]) / max_Time)) {
				new_max_acc[i] = (max_vel[i] * max_vel[i]) / (theta_start[i] - theta_end[i] + (theta_max[i] * max_Time));
			}
			/*for (double t = 0; t < max_Time; t += 0.01) {
			if (t <= t_mean_new[i]) {
			theta = theta_start[i] + 0.5 * max_acc[i] * t * t;

			vel = new_max_acc[i] * t;

			acc = new_max_acc[i];
			}
			if (t > t_mean_new[i]) {
			theta = theta_start[i] + (0.5 * new_max_acc[i] * t * t) - (0.5 * new_max_acc[i] * (t - max_Time) * (t - max_Time)) + (0.5 * new_max_acc[i] * t_mean_new[i] * t_mean_new[i]);

			vel = -new_max_acc[i] * (t - t_mean_new[i]) + new_max_acc[i] * t_mean_new[i];

			acc = -new_max_acc[i];
			}

			if (t <= t_max_new[i]) {
			theta = 0.5 * new_max_acc[i] * t * t;

			vel = new_max_acc[i] * t;

			acc = new_max_acc[i];
			}
			else if (t_max_new[i] < t && t <= (max_Time - t_max_new[i])) {

			theta = (0.5 * new_max_acc[i] * t * t) + (t - t_max_new[i]) * vel;
			vel = max_vel[i];
			acc = 0;
			}
			else if ((max_Time - t_max_new[i]) < t) {
			theta = (0.5 * new_max_acc[i] * max_Time * max_Time) + ((max_Time - 2 * t_max_new[i]) * max_vel[i]) - (0.5 * new_max_acc[i] * (t - t_max_new[i]) * (t - t_max[i])) + (0.5 * new_max_acc[i] * max_Time * max_Time);
			vel = max_vel[i] - ((t - ((max_Time - t_max_new[i])) * new_max_acc[i]));
			acc = -new_max_acc[i];
			}

			}*/
		}
		//cout << theta << " " << vel << " " << acc << "\n";

	}
	return theta, vel, acc;

}
